/* ===========================================================
   ScreenSaver 配置窗口（/c）—— 极简入口页
   宿主 → 页面：init / centerResult / previewResult
   页面 → 宿主：ready / openCenter / preview / close
   =========================================================== */
'use strict';

(function () {
  const $ = (id) => document.getElementById(id);
  const bridge = (window.chrome && window.chrome.webview) ? window.chrome.webview : null;

  let centerAvailable = false;
  let toastTimer = 0;

  /* ---------------- 与宿主通信 ---------------- */

  function post(obj) {
    if (bridge) {
      bridge.postMessage(obj);
    } else {
      console.log('[demo] → host', obj);
    }
  }

  function onHost(raw) {
    const msg = (typeof raw === 'string') ? safeParse(raw) : raw;
    if (!msg || !msg.type) return;

    switch (msg.type) {
      case 'init':
        applyInit(msg);
        break;
      case 'centerResult':
        if (!msg.ok) {
          toast('打开设置中心失败：' + (msg.msg || ('错误码 ' + msg.err)), 'error');
        }
        break;
      case 'previewResult':
        if (msg.ok) {
          toast('预览已启动，点右上角“退出屏保”结束', 'ok');
        } else {
          toast('预览启动失败', 'error');
        }
        break;
      default:
        break;
    }
  }

  function safeParse(text) {
    try { return JSON.parse(text); } catch (e) { return null; }
  }

  /* ---------------- 初始化 ---------------- */

  function applyInit(d) {
    centerAvailable = !!d.centerAvailable;

    const btn = $('btnCenter');
    const hint = $('hint');
    btn.disabled = !centerAvailable;

    if (centerAvailable) {
      btn.title = d.centerPath || '';
    } else {
      btn.title = '没有找到 zkdesk64.exe';
      hint.classList.add('warn');
      hint.textContent = '没有找到 ZkDesk 主程序，请在 ZkDesk 设置中心里修改屏保设置。';
    }
  }

  /* ---------------- 交互 ---------------- */

  function toast(text, kind) {
    const box = $('toast');
    $('toastText').textContent = text;
    box.classList.toggle('error', kind === 'error');
    box.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => box.classList.remove('show'), 2600);
  }

  function bind() {
    $('btnCenter').addEventListener('click', () => {
      if (!centerAvailable) return;
      post({ type: 'openCenter' });
    });

    $('btnPreview').addEventListener('click', () => post({ type: 'preview' }));
    $('btnClose').addEventListener('click', () => post({ type: 'close' }));

    // Esc = 关闭（WebView 的按键不会自动传给宿主对话框）
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        post({ type: 'close' });
      }
    });
  }

  /* ---------------- 启动 ---------------- */

  bind();
  if (bridge) {
    bridge.addEventListener('message', (e) => onHost(e.data));
  }
  post({ type: 'ready' });
})();
