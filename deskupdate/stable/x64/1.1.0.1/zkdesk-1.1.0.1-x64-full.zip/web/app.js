/* ScreenSaver 内置页面脚本：时钟 + 日期 + 轻量粒子 */
(function () {
  'use strict';

  var mode = window.__SAVER_MODE__ || 'full';
  var isPreview = mode === 'preview';
  if (isPreview) {
    document.body.classList.add('preview');
  }

  /* ---------------- 退出按钮 ---------------- */
  // 屏保不再响应鼠标/键盘退出（避免碰到鼠标就退），
  // 只有点击右上角按钮才算一次退出事件。
  function postExit() {
    var bridge = window.chrome && window.chrome.webview;
    if (bridge) {
      bridge.postMessage({ type: 'exit' });
    }
  }

  var exitBtn = document.getElementById('btnExit');
  if (exitBtn) {
    // 只认“真实鼠标点击”：键盘触发的 click 事件 detail 为 0，一律忽略，
    // 避免空格/回车（哪怕按钮意外获得焦点）把屏保关掉。
    exitBtn.addEventListener('mousedown', function (e) {
      e.preventDefault(); // 不让按钮抢焦点
    });
    exitBtn.addEventListener('click', function (e) {
      if (!e.isTrusted || e.detail === 0) {
        return;
      }
      e.preventDefault();
      e.stopPropagation();
      postExit();
    });
  }

  /* ---------------- 时钟 / 日期 ---------------- */
  var elClock = document.getElementById('clock');
  var elClockSub = document.getElementById('clockSub');
  var elDate = document.getElementById('date');
  var elWeekday = document.getElementById('weekday');

  var WEEKDAYS = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];

  function pad2(n) {
    return n < 10 ? '0' + n : String(n);
  }

  function renderTime() {
    var now = new Date();
    var h = pad2(now.getHours());
    var m = pad2(now.getMinutes());
    var s = pad2(now.getSeconds());

    if (elClock.textContent !== h + ':' + m) {
      elClock.textContent = h + ':' + m;
    }
    elClockSub.textContent = s;

    var dateText = now.getFullYear() + '年' + (now.getMonth() + 1) + '月' + now.getDate() + '日';
    if (elDate.textContent !== dateText) {
      elDate.textContent = dateText;
    }
    elWeekday.textContent = WEEKDAYS[now.getDay()];
  }

  renderTime();
  setInterval(renderTime, 500);

  /* ---------------- 粒子背景 ---------------- */
  var canvas = document.getElementById('particles');
  var ctx = canvas.getContext('2d', { alpha: true });
  var dpr = Math.min(window.devicePixelRatio || 1, 2);
  var width = 0;
  var height = 0;
  var particles = [];
  var COUNT = isPreview ? 28 : 90;

  function resize() {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.max(1, Math.floor(width * dpr));
    canvas.height = Math.max(1, Math.floor(height * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function makeParticle(randomY) {
    return {
      x: Math.random() * width,
      y: randomY ? Math.random() * height : height + Math.random() * 40,
      r: 0.5 + Math.random() * 1.8,
      vy: -(0.08 + Math.random() * 0.32),
      vx: (Math.random() - 0.5) * 0.12,
      phase: Math.random() * Math.PI * 2,
      speed: 0.4 + Math.random() * 1.2,
      alpha: 0.15 + Math.random() * 0.5
    };
  }

  function resetParticles() {
    particles = [];
    for (var i = 0; i < COUNT; i++) {
      particles.push(makeParticle(true));
    }
  }

  var last = 0;

  function frame(now) {
    var dt = last ? Math.min(now - last, 64) : 16;
    last = now;

    ctx.clearRect(0, 0, width, height);

    for (var i = 0; i < particles.length; i++) {
      var p = particles[i];
      p.phase += (p.speed * dt) / 1000;
      p.x += p.vx * (dt / 16);
      p.y += p.vy * (dt / 16);

      if (p.y < -20 || p.x < -20 || p.x > width + 20) {
        particles[i] = makeParticle(false);
        continue;
      }

      var twinkle = 0.55 + 0.45 * Math.sin(p.phase);
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(190, 230, 255, ' + (p.alpha * twinkle).toFixed(3) + ')';
      ctx.fill();
    }

    requestAnimationFrame(frame);
  }

  resize();
  resetParticles();
  requestAnimationFrame(frame);

  var resizeTimer = 0;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      resize();
      resetParticles();
    }, 120);
  });

  // 页面隐藏时暂停绘制，省电
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) {
      last = 0;
    }
  });
})();
